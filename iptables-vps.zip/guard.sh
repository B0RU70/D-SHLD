#!/bin/bash

# Accept already established connections (so it doesnt drop your current SSH session)
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# Accept SSH connections from anywhere
iptables -A INPUT -p tcp -i eth0 --dport ssh -j ACCEPT

# (Optional) Accept HTTP connections from anywhere
iptables -A INPUT -p tcp -i eth0 --dport 80 -j ACCEPT

# Block all other connections!
iptables -A INPUT -j DROP

# Unblock loopback interface
iptables -I INPUT 4 -i lo -j ACCEPT

# Enable logging of denied connections
iptables -I INPUT 5 -m limit --limit 5/min -j LOG --log-prefix "iptables denied: " --log-level 7

# Print current iptables rules
iptables -L -v

# Save current rules
iptables-save > /etc/iptables.up.rules

# (Manual step) Loading rules after boot:
# vi /etc/network/interfaces
# auto eth0
# iface eth0 inet dhcp
#   pre-up iptables-restore < /etc/iptables.up.rules
#   post-down iptables-restore < /etc/iptables.down.rules